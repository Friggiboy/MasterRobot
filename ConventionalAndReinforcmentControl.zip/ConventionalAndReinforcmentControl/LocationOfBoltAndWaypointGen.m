
%k=[1 1 1 1 1 1 1]
%open_system('IKTrajectoryControlExample.slx');
%simin = [-1 1.22e-16 0 0.6;0 1 0 -0.3;-1.225e-16 0 -1 0.05;0 0 0 1];
% error= 1-1/(0.5^-0.5)  error function


% Import the manipulator as a rigidBodyTree Object
robot = importrobot('ur5_robot.urdf');
%[robot,importInfo] = importrobot(simscape)

robot.DataFormat = 'column';
robot.Gravity = [0 0 -9.81]
% Define end-effector body name
eeName = 'ee_link';
%[H,dataFileName] = smimport(simscape123.slxc)
% Define the number of joints in the manipulator
numJoints = 6;
eeOrientation = [0, pi, 0];% The Euler angles for the desired end effector orientation at each point must 
% also be defined.
clear wayPoints
%% 
%  BOLT DETECTION 

RGB = imread('final2.png');
imshow(RGB);
I = im2bw(RGB);
%imshow(I);
bw= imcomplement(I); % convert black and white 
BW2 = bwareaopen(bw,300); %150000     470000% 
% bw = imfill(BW2,'holes');
% imshow(bw)
[B,L] = bwboundaries(BW2,'noholes');
%imshow(label2rgb(L,@jet,[.5 .5 .5]))
hold on
for k = 1:length(B)
  boundary = B{k};
  plot(boundary(:,2),boundary(:,1),'w','LineWidth',2)
  
end
scale = 0.0015/2;% 0.00015 med bilde boltgreen  0.000075/2  0.00035
segment = B{1}*scale;   % translate from pixels to distance (m)   
  
%segment2 = B{2}*scale;  
% bw_filled = imfill(bw,'holes');
% boundaries = bwboundaries(bw_filled);    
imageOrigin = [0.2,0,0.0];    

    % Z-offset for moving between boundaries
  segment(1,3) = .0;
  segment2(1,3) = .0;
%      Translate to origin of image
    cord = imageOrigin + segment;
    cord2 = imageOrigin + segment2;
%      bolt origin x cord
%%
% BOLT LOCATION   

% bolt 1 location in global kordinate system 
   Bolt1xWidth = max(cord(:,1))-min((cord(:,1)));  % bolt 1 width = x maxValue - x minValue
   Bolt1xLocation=min(cord(:,1))+Bolt1xWidth/2;    % bolt1 x cordinates = start off left bolt + bolt width
  
   Bolt1yWidth = max(cord(:,2))-min((cord(:,2)));
   Bolt1yLocation=min(cord(:,2))+ Bolt1yWidth/2;
   Bolt1Center(1,1)=Bolt1xLocation;
   Bolt1Center(1,2)=Bolt1yLocation;
% bolt2 location in global kordinate system  
   
   Bolt2xWidth = max(cord2(:,1))-min((cord2(:,1)));   % bolt 2width = x maxValue - x minValue
   Bolt2xLocation=min(cord2(:,1))+Bolt2xWidth/2;    % bolt2x cordinates = start off left bolt + bolt width
    
   Bolt2yWidth = max(cord2(:,2))-min((cord2(:,2)));
   Bolt2yLocation=min(cord2(:,2))+ Bolt2yWidth/2;
   
   Bolt2Center(1,1)=Bolt2xLocation;
   Bolt2Center(1,2)=Bolt2yLocation;

%% 
 % WAYPOINT GENERATION

% Start just above image origin
%waypt0 = [imageOrigin + [0 0 .2],eeOrientation]
waypt0 = [0.2 0.2 0.2,eeOrientation]% where to start 
%imageOrigin = [0.6 -0.3 0.05];
Bolt1Center(1,3) = .0;
Bolt2Center(1,3) = .0;   %  add column 

waypt1 = [Bolt1Center,0,pi/2,0];%  Target location 
%waypt1 = [imageOrigin+Bolt2Center,eeOrientation];%  Target location 
% Interpolate each element for smooth motion to the origin of the image
for i = 1:6    
    interp = linspace(waypt0(i),waypt1(i),100);
    %eulerAngles = repmat(eeOrientation,size(segment,1),1);
    wayPoints(:,i) = interp';    
end

q0 = zeros(numJoints,1);

% Define a sampling rate for the simulation.
%Ts = .001;

weights = [1 1 1 1 1 1];
% Transform the first waypoint to a Homogenous Transform Matrix for initialization
% 
initTargetPose = eul2tform(wayPoints(1,4:6));
% 
initTargetPose(1:3,end) = wayPoints(1,1:3)';
% 
% Solve for q0 such that the manipulator begins at the first waypoint
 ik = inverseKinematics('RigidBodyTree',robot);
 [q0,solInfo] = ik(eeName,initTargetPose,weights,q0);

% 
% targetPose = eul2tform(wayPoints(1,4:6))
%  wayPoints(1,4:6)
% targetPose(1:3,:)
% wayPoints(1,1:3)'
%  error = vecnorm(targetPose(1:3,:) - currentEEPose(1:3,:), 2, 1)

% Remove unnecessary meshes for faster visualization

%sim('robotsim.slx');
%

%  VIZULATION OFF ROBOT 
%  VIZULATION OFF ROBOT 
% show(robot);
% xlim([-1.00 1.00])
% ylim([-1.00 1.00]);
% zlim([-1.02 0.98]);
% view([128.88 10.45]);
%clearMeshes(robot);

% Data for mapping image
% [m,n] = size(BW2);
% 
% [X,Y] = meshgrid(0:m,0:n);
% X = imageOrigin(1) + X*scale;
% Y = imageOrigin(2) + Y*scale;
% Z = zeros(size(X));
% Z = Z + imageOrigin(3);
% % Close all open figures
% close all
% % Initialize a new figure window
% figure;
% set(gcf,'Visible','on');
% 
% % Plot the initial robot position
% show(robot, jointData1(1,:)');
% hold on
% % Initialize end effector plot position
% p = plot3(0,0,0,'.');
% warp(X,Y,Z,BW2');
% 
% % Change view angle and axis
% view(0,45)
% axis([-0.25 1 -0.25 0.6 0 0.75])
% 
% % Iterate through the outputs at 10-sample intervals to visualize the results
% for j = 1:10:length(jointData1)
%     % Display manipulator model
%     show(robot,jointData1(j,:)', 'Frames','off','PreservePlot', false);
%     %show(robot,config,'Collisions','on','Visuals','off');
%     % Get end effector position from homoegenous transform output
%     pos = poseData1(1:3,4,j);
%      %'Frames', 'off','Collisions','on' 'PreservePlot', false);
%     % Update end effector position for plot
%     p.XData = [p.XData pos(1)];
%     p.YData = [p.YData pos(2)];
%     p.ZData = [p.ZData pos(3)];    
%     % Update figure
%     drawnow
% end


targetPose = eul2tform(wayPoints(1,4:6)) % euler angulars from waypoint 
targetPose(1:3,end) = wayPoints(1,1:3)'



