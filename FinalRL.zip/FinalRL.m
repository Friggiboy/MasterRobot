
% error=[0:0.01:0.3]   

%  reward=(1-(1./0.01).^-0.5)*3 %reward function validation

%  rewardtest=(1-(1/0.002)^-0.5)*8

%plot(error,reward)
%open_system('robotsim')
%open_system('robotsimTrain')
obsInfo = rlNumericSpec([12 1],...
      'LowerLimit',[-inf -inf -inf -inf -inf -inf -inf -inf -inf -inf -inf -inf]',...
      'UpperLimit',[ inf inf inf inf inf inf inf inf inf inf inf inf]');
 obsInfo.Name = 'observations';
 obsInfo.Description = 'conf, vel'; % legge inn alle 12 verdiene 
 numObservations = obsInfo.Dimension(1);
 
actInfo = rlNumericSpec([6 1])
actInfo.Name = 'Torque';
numActions = actInfo.Dimension(1);

%env = rlSimulinkEnv('robotsim','robotsim/EnabledReinforcment/RL Agent',obsInfo,actInfo);

env = rlSimulinkEnv('RobotsimFinal2','RobotsimFinal2/EnabledReinforcment1/RL Agent',obsInfo,actInfo);

%env.ResetFcn = @(in)localResetFcn(in);% The robot is put in place close to
%the target screw, so this is not needed.

Ts = 0.001;
Tf = 50;


rng(0)
% Ts = 0.0001;
% Tf = 20;
% Ts = 1.0;
% Tf = 200;

% CREATE AGENT DDPG
statePath = [
    featureInputLayer(numObservations,'Normalization','none','Name','State')
    fullyConnectedLayer(50,'Name','CriticStateFC1')
    reluLayer('Name','CriticRelu1')
    fullyConnectedLayer(25,'Name','CriticStateFC2')];
actionPath = [
    featureInputLayer(numActions,'Normalization','none','Name','Action')
    fullyConnectedLayer(25,'Name','CriticActionFC1')];
commonPath = [
    additionLayer(2,'Name','add')
    reluLayer('Name','CriticCommonRelu')
    fullyConnectedLayer(1,'Name','CriticOutput')];

criticNetwork = layerGraph();
criticNetwork = addLayers(criticNetwork,statePath);
criticNetwork = addLayers(criticNetwork,actionPath);
criticNetwork = addLayers(criticNetwork,commonPath);
criticNetwork = connectLayers(criticNetwork,'CriticStateFC2','add/in1');
criticNetwork = connectLayers(criticNetwork,'CriticActionFC1','add/in2');

criticOpts = rlRepresentationOptions('LearnRate',1e-03,'GradientThreshold',1);

critic = rlQValueRepresentation(criticNetwork,obsInfo,actInfo,'Observation',{'State'},'Action',{'Action'},criticOpts);

%construct actor

actorNetwork = [
    featureInputLayer(numObservations,'Normalization','none','Name','State')
    fullyConnectedLayer(3, 'Name','actorFC')
    tanhLayer('Name','actorTanh')
    fullyConnectedLayer(numActions,'Name','Action')
    ];

actorOptions = rlRepresentationOptions('LearnRate',1e-04,'GradientThreshold',1);

actor = rlDeterministicActorRepresentation(actorNetwork,obsInfo,actInfo,'Observation',{'State'},'Action',{'Action'},actorOptions);


agentOpts = rlDDPGAgentOptions(...
    'SampleTime',Ts,...
    'TargetSmoothFactor',1e-3,...
    'DiscountFactor',1.0, ...
    'MiniBatchSize',64, ...
    'ExperienceBufferLength',1e6); 
agentOpts.NoiseOptions.StandardDeviation = 0.3;
agentOpts.NoiseOptions.StandardDeviationDecayRate = 1e-5;

agent = rlDDPGAgent(actor,critic,agentOpts);
maxsteps = ceil(500); % train 28.05 value 250
maxepisodes = 5000;
%maxsteps = ceil(Tf/Ts);
%maxsteps = ceil(0.0001);
trainOpts = rlTrainingOptions(...
    'MaxEpisodes',maxepisodes, ...
    'MaxStepsPerEpisode',maxsteps, ...
    'ScoreAveragingWindowLength',5, ... %5
    'Verbose',false, ...
    'Plots','training-progress',...
    'StopTrainingCriteria','AverageReward',...
    'StopTrainingValue',50000,...
    'SaveAgentCriteria','EpisodeReward',...
    'SaveAgentValue',300);
  

load('Agent8410','saved_agent');
agent = saved_agent;

 %simOpts = rlSimulationOptions('MaxSteps',maxsteps,'StopOnError','on');
 %experiences = sim(env,agent,simOpts);

%load('agent.mat','agent')
%trainingStats = train(agent,env,trainOpts);
